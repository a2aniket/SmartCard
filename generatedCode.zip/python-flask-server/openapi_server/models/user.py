from __future__ import absolute_import
from werkzeug.security import generate_password_hash, check_password_hash
from openapi_server.config_test import db,ma

class User(db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(32), nullable=False, unique=True)
    password = db.Column(db.String(128), nullable=False)

    def __init__(self, username, password):
        self.username = username
        self.set_password(password)

    def set_password(self, password):
        self.password = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password, password)

    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
        }

class UserSchema(ma.SQLAlchemyAutoSchema):
    class Meta:
        model = User