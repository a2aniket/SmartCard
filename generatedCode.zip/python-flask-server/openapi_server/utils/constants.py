#DEFAULT PARAMETERS: 
pageNumber = 1
pageSize = 100
sortBy = 'id'
sortDir = 'asc'
search=''

#PARAMETERS:
PARAM_PAGE_NUMBER = 'pageNumber'
PARAM_PAGE_SIZE = 'pageSize'
PARAM_SORT_BY = 'sortBy'
PARAM_SORT_DIR = 'sortDir'
PARAM_SEARCH = 'search'